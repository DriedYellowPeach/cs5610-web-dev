/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const main: (a: number, b: number) => number;
export const __wbindgen_export_0: (a: number) => void;
export const __wbindgen_export_1: (a: number, b: number) => number;
export const __wbindgen_export_2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_3: (a: number, b: number, c: number) => void;
export const __wbindgen_export_4: WebAssembly.Table;
export const __wbindgen_export_5: (a: number, b: number, c: number) => void;
export const __wbindgen_export_6: (a: number, b: number) => void;
export const __wbindgen_export_7: (a: number, b: number, c: number, d: number) => void;
export const __wbindgen_export_8: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
